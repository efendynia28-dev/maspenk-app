# MP mini APK

GitHub Actions builds a debug APK from `android_project`.

1. Upload this ZIP contents to a GitHub repository.
2. Open Actions → MASPENK MP mini APK Build.
3. Run workflow.
4. Open the successful run → Artifacts → mp-mini-apk.
5. Download `app-debug.apk`.
