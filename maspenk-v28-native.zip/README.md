# MASPENK App

MASPENK V28 Native Cloud Android.

Debug APK: GitHub Actions artifact maspenk-v28-apk.
