# MASPENK App

MASPENK V27 Native Cloud Android.

Debug APK: GitHub Actions artifact maspenk-v27-apk.
