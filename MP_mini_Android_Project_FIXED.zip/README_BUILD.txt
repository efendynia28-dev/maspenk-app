MP mini — FIXED APK PROJECT

Perbaikan:
- Editor HTML/CSS/JS tetap editable di WebView Android.
- Pointer/touch dan caret editor dipaksa aktif.
- Keyboard Android menggunakan adjustResize + WebView focus.
- Nama aplikasi: MP mini.
- Native Engine V28 tidak diubah.

Build dari HP:
1. Upload folder ini ke GitHub.
2. Gunakan Android build workflow/Actions atau Android IDE.
3. APK debug: app/build/outputs/apk/debug/app-debug.apk
