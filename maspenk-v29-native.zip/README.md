# MASPENK App

MASPENK V29 Native Cloud Android.

Debug APK: GitHub Actions artifact maspenk-v28-apk.
