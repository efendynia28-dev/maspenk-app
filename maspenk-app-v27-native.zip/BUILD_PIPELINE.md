Upload this project ZIP to the MASPENK GitHub repository. The repository workflow extracts it and builds the debug APK.
