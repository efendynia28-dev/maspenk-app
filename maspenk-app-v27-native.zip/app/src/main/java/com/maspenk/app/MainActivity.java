package com.maspenk.app;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import org.json.JSONObject;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;
    LocationManager lm;
    LocationListener ll;
    Uri cameraUri;
    static final int CAM=7001, FILE=7002, LOC=7003, NOTIF=7004;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        web.addJavascriptInterface(new MaspenkBridge(this), "MaspenkNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String u) { handle(getIntent()); }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    void handle(Intent i) {
        if (i != null && i.getData() != null) {
            Uri d = i.getData();
            js("window.dispatchEvent(new CustomEvent('maspenk:deeplink',{detail:{fullUrl:"+q(d.toString())+",scheme:"+q(d.getScheme())+",host:"+q(d.getHost())+",path:"+q(d.getPath())+",query:"+q(d.getQuery())+"}}));");
        }
    }
    String q(String x) { return JSONObject.quote(String.valueOf(x)); }
    void js(String x) { if (web != null) web.post(() -> web.evaluateJavascript(x, null)); }
    void toast(String x) { Toast.makeText(this, String.valueOf(x), Toast.LENGTH_SHORT).show(); }

    void camera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAM); return;
        }
        try {
            File d = new File(getExternalFilesDir("Pictures"), "maspenk"); d.mkdirs();
            File f = File.createTempFile("IMG_", ".jpg", d);
            cameraUri = FileProvider.getUriForFile(this, getPackageName()+".fileprovider", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(i, CAM);
        } catch (Exception e) { toast(e.getMessage()); }
    }

    void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, FILE);
    }

    void gps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOC); return;
        }
        lm = (LocationManager)getSystemService(LOCATION_SERVICE);
        String p = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
        ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                js("window.dispatchEvent(new CustomEvent('maspenk:gps',{detail:{latitude:"+l.getLatitude()+",longitude:"+l.getLongitude()+",accuracy:"+l.getAccuracy()+",timestamp:"+l.getTime()+"}}));");
                stopGps();
            }
            @Override public void onProviderEnabled(String p) {}
            @Override public void onProviderDisabled(String p) {}
        };
        try {
            Location z = lm.getLastKnownLocation(p);
            if (z != null) {
                js("window.dispatchEvent(new CustomEvent('maspenk:gps',{detail:{latitude:"+z.getLatitude()+",longitude:"+z.getLongitude()+",accuracy:"+z.getAccuracy()+",timestamp:"+z.getTime()+"}}));");
                return;
            }
            lm.requestLocationUpdates(p, 1000, 1, ll);
            new Handler().postDelayed(() -> stopGps(), 15000);
        } catch (Exception e) { toast(e.getMessage()); }
    }
    void stopGps() { if (lm != null && ll != null) try { lm.removeUpdates(ll); } catch (Exception e) {} ll = null; }

    void notifyNative(String t, String m) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF); return;
        }
        NotificationManager n = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) n.createNotificationChannel(new NotificationChannel("maspenk", "MASPENK", NotificationManager.IMPORTANCE_DEFAULT));
        Notification x = new Notification.Builder(this).setContentTitle(t).setContentText(m).setSmallIcon(android.R.drawable.ic_dialog_info).setChannelId("maspenk").build();
        n.notify((int)(System.currentTimeMillis() & 0x7fffffff), x);
    }

    void share(String t) { Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, t); startActivity(Intent.createChooser(i, "Bagikan")); }
    void download(String u) {
        if (!u.startsWith("https://") && !u.startsWith("http://")) { toast("URL tidak aman"); return; }
        try { DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE); dm.enqueue(new DownloadManager.Request(Uri.parse(u)).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)); }
        catch (Exception e) { toast(e.getMessage()); }
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == CAM) js("window.dispatchEvent(new CustomEvent('maspenk:camera',{detail:{uri:"+(cameraUri == null ? "null" : q(cameraUri.toString()))+"}}));");
        else if (r == FILE && c == RESULT_OK && d != null && d.getData() != null) js("window.dispatchEvent(new CustomEvent('maspenk:file',{detail:{uri:"+q(d.getData().toString())+"}}));");
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) { if (r == CAM) camera(); else if (r == LOC) gps(); else if (r == NOTIF) notifyNative("MASPENK", "Notifikasi aktif"); }
    }
    @Override public void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handle(i); }
    @Override protected void onDestroy() { stopGps(); if (web != null) web.destroy(); super.onDestroy(); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
