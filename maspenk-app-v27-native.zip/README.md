# MASPENK V27 Native Android

Debug APK is built by GitHub Actions.
